import 'package:bamtol_market_app/src/common/components/app_font.dart';
import 'package:bamtol_market_app/src/root.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ProductRegisterPage extends StatefulWidget {
  const ProductRegisterPage({super.key});

  @override
  State<ProductRegisterPage> createState() => _ProductRegisterPageState();
}

class _ProductRegisterPageState extends State<ProductRegisterPage> {
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late TextEditingController _locationController;
  late TextEditingController _priceController;
  late SharedPreferences prefs;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController();
    _descriptionController = TextEditingController();
    _locationController = TextEditingController();
    _priceController = TextEditingController();
    _initPrefs();
  }

  Future<void> _initPrefs() async {
    prefs = await SharedPreferences.getInstance();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  void _registerProduct() async {
    if (_titleController.text.isEmpty ||
        _descriptionController.text.isEmpty ||
        _locationController.text.isEmpty) {
      Get.snackbar('오류', '모든 필드를 입력해주세요');
      return;
    }

    try {
      // SharedPreferences 초기화 대기
      await _initPrefs();

      // 새 상품 정보
      final newProduct = {
        'image': 'assets/images/logo_simbol.png',
        'title': _titleController.text,
        'nickname': prefs.getString('user_name') ?? '사용자',
        'date': '방금 전',
        'description': _descriptionController.text,
        'location': _locationController.text,
        'price': _priceController.text.isEmpty ? '' : _priceController.text,
      };

      // 기존 상품 리스트 불러오기
      final productsJson = prefs.getStringList('products') ?? [];
      productsJson.insert(0, jsonEncode(newProduct)); // 맨 앞에 추가
      
      // 저장
      await prefs.setStringList('products', productsJson);

      print('상품 저장 완료');

      if (mounted) {
        Get.snackbar('성공', '상품이 등록되었습니다');
        // 300ms 후에 홈으로 이동
        await Future.delayed(const Duration(milliseconds: 300));
        Get.offAll(() => const Root());
      }
    } catch (e) {
      print('에러: $e');
      Get.snackbar('오류', '상품 등록 중 오류가 발생했습니다: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFont('새 상품 등록', size: 18, fontWeight: FontWeight.bold),
        centerTitle: true,
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 이미지 추가
              GestureDetector(
                onTap: () {
                  Get.snackbar('알림', '이미지 선택 기능은 준비 중입니다');
                },
                child: Container(
                  width: double.infinity,
                  height: 200,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey[700]!),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.camera_alt,
                          color: Colors.grey[500], size: 40),
                      const SizedBox(height: 10),
                      AppFont(
                        '사진 추가',
                        color: Colors.grey[500],
                        size: 16,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30),
              // 제목
              const AppFont(
                '제목',
                size: 14,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _titleController,
                maxLines: 1,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: '상품 제목을 입력해주세요',
                  hintStyle: TextStyle(color: Colors.grey[600]),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[700]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.orange),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
              ),
              const SizedBox(height: 20),
              // 설명
              const AppFont(
                '설명',
                size: 14,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _descriptionController,
                maxLines: 5,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: '상품 설명을 입력해주세요',
                  hintStyle: TextStyle(color: Colors.grey[600]),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[700]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.orange),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
              ),
              const SizedBox(height: 20),
              // 거래 장소
              const AppFont(
                '거래 장소',
                size: 14,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _locationController,
                maxLines: 1,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: '거래 장소를 입력해주세요',
                  hintStyle: TextStyle(color: Colors.grey[600]),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[700]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.orange),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
              ),
              const SizedBox(height: 20),
              // 가격
              const AppFont(
                '가격 (선택사항)',
                size: 14,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _priceController,
                maxLines: 1,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: '가격을 입력하거나 비워두면 나눔으로 표시됩니다',
                  hintStyle: TextStyle(color: Colors.grey[600]),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[700]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.orange),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
              ),
              const SizedBox(height: 40),
              // 등록 버튼
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _registerProduct,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const AppFont(
                    '상품 등록',
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    size: 16,
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
