import 'package:bamtol_market_app/src/common/components/app_font.dart';
import 'package:bamtol_market_app/src/home/page/product_register_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late SharedPreferences prefs;
  List<Map<String, String>> _productList = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    prefs = await SharedPreferences.getInstance();
    _refreshProducts();
  }

  void _refreshProducts() {
    final productsJson = prefs.getStringList('products') ?? [];
    final products = productsJson
        .map((json) => Map<String, String>.from(jsonDecode(json)))
        .toList();
    
    setState(() {
      _productList = products;
      _isLoading = false;
    });
  }

  PreferredSizeWidget _header() {
    return AppBar(
      leadingWidth: Get.width * 0.6,
      leading: Padding(
        padding: const EdgeInsets.only(left: 16.0),
        child: Row(
          children: [
            const SizedBox(width: 10),
            const AppFont(
              '성남시',
              size: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            const SizedBox(width: 8),
            const Icon(
              Icons.expand_more,
              color: Colors.white,
              size: 20,
            ),
          ],
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.search, color: Colors.white),
          onPressed: () {},
        ),
        IconButton(
          icon: const Icon(Icons.list, color: Colors.white),
          onPressed: () {},
        ),
        IconButton(
          icon: const Icon(Icons.notifications, color: Colors.white),
          onPressed: () {},
        ),
      ],
      elevation: 0,
      backgroundColor: Colors.black,
    );
  }

  Widget _productItem(Map<String, String> product) {
    final price = product['price'] ?? '';
    final priceText = price.isEmpty ? '나눔' : '₩${price}원';
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(
              product['image']!,
              width: 100,
              height: 100,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AppFont(
                  product['title']!,
                  size: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    AppFont(
                      product['nickname']!,
                      size: 12,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 8),
                    AppFont(
                      product['date']!,
                      size: 12,
                      color: Colors.grey,
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                AppFont(
                  priceText,
                  size: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _body() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
        ),
      );
    }

    if (_productList.isEmpty) {
      return Center(
        child: AppFont(
          '등록된 상품이 없습니다',
          size: 16,
          color: Colors.grey,
        ),
      );
    }

    return ListView.separated(
      itemCount: _productList.length,
      itemBuilder: (context, index) {
        return _productItem(_productList[index]);
      },
      separatorBuilder: (context, index) {
        return Divider(
          color: Colors.grey[800],
          height: 1,
          indent: 16,
          endIndent: 16,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _header(),
      body: _body(),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Get.to(() => const ProductRegisterPage());
          _refreshProducts();
        },
        backgroundColor: Colors.orange,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}