import 'package:bamtol_market_app/src/common/components/app_font.dart';
import 'package:bamtol_market_app/src/common/controller/bottom_nav_controller.dart';
import 'package:bamtol_market_app/src/home/page/home_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Root extends StatefulWidget {
  const Root({super.key});

  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> with TickerProviderStateMixin {
  late BottomNavController controller;

  @override
  void initState() {
    super.initState();
    controller = BottomNavController();
    controller.tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    controller.tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: TabBarView(
          physics: const NeverScrollableScrollPhysics(),
          controller: controller.tabController,
          children: const [
            HomePage(),
            Center(child: AppFont('동네생활')),
            Center(child: AppFont('내 근처')),
            Center(child: AppFont('채팅')),
            Center(child: AppFont('나의 밤톨')),
          ]),
      bottomNavigationBar: Obx(
        () => BottomNavigationBar(
          currentIndex: controller.menuIndex.value,
          type: BottomNavigationBarType.fixed,
          backgroundColor: const Color(0xff212123),
          selectedItemColor: Colors.orange,
          unselectedItemColor: Colors.grey,
          selectedFontSize: 11.0,
          unselectedFontSize: 11.0,
          onTap: controller.changeBottomNav,
          items: const [
            BottomNavigationBarItem(
              label: '홈',
              icon: Icon(Icons.home),
            ),
            BottomNavigationBarItem(
              label: '동네생활',
              icon: Icon(Icons.location_city),
            ),
            BottomNavigationBarItem(
              label: '내 근처',
              icon: Icon(Icons.near_me),
            ),
            BottomNavigationBarItem(
              label: '채팅',
              icon: Icon(Icons.chat),
            ),
            BottomNavigationBarItem(
              label: '나의 밤톨',
              icon: Icon(Icons.person),
            ),
          ],
        ),
      ),
    );
  }
}