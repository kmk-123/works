import 'package:get/get.dart';

class LoginController extends GetxController {
  void googleLogin() async {
    print('Google 로그인 시도');
  }

  void appleLogin() async {
    print('Apple 로그인 시도');
  }
}
