class AuthenticationRepository {
  Future<void> signInWithGoogle() async {
    // Google 로그인 구현
    print('Google 로그인 시도');
  }

  Future<void> signInWithApple() async {
    // Apple 로그인 구현
    print('Apple 로그인 시도');
  }
}
