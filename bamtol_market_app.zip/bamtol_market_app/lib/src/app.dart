import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:get/get.dart';
import 'splash/page/splash_page.dart';
import 'root.dart';

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  late SharedPreferences prefs;
  bool isFirstRun = true;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _initPrefs();
  }

  Future<void> _initPrefs() async {
    prefs = await SharedPreferences.getInstance();
    isFirstRun = prefs.getBool('isFirstRun') ?? true;
    
    setState(() {
      isLoading = false;
    });
  }

  void _onSplashComplete() async {
    await prefs.setBool('isFirstRun', false);
    Get.off(() => const Root());
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    // 첫 방문자: splash_page 표시
    if (isFirstRun) {
      return SplashPage(onComplete: _onSplashComplete);
    }

    // 재방문자: 바로 Root로 이동
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.off(() => const Root());
    });

    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}